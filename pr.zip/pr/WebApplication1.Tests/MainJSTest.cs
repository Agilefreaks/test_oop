﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WebApplication1.Tests
{
    [TestClass]
    public class MainJSTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            

        }
    }
}
